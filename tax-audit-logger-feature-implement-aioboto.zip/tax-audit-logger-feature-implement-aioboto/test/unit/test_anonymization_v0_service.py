import dataclasses
import io
import json
import unittest
import uuid

from datetime import datetime

from tax_audit_logger.persistence.audit_document import AuditDocument
from tax_audit_logger.service import anonymization_v0_service, anonymization_parameters


class AnonymizationV0ServiceTest(unittest.TestCase):

    def setUp(self):
        self.tenant_id = str(uuid.uuid4())
        self.correlation_id = str(uuid.uuid4())
        self.creation = str(datetime.utcnow().isoformat())

    def test_should_anonymize_fields_GSSITAASHAL_1390(self):
        for combination in self.create_audit_document_combinations():
            should_be_anonymized = anonymization_v0_service.should_be_anonymized(
                combination['audit_document'])
            self.assertEqual(should_be_anonymized, combination['is_dpp_relevant'],
                             "The document does not match the expected")

    def create_audit_document_combinations(self):
        return [
            {
                "audit_document": AuditDocument(_id=str(uuid.uuid4()),
                                                tenant_id=self.tenant_id,
                                                correlation_id=self.correlation_id,
                                                creation=self.creation,
                                                quote_request={
                                                    "Party": [{
                                                        "taxRegistration": [{
                                                            "taxNumber": "Y",
                                                            "taxNumberTypeCode": "isNaturalPerson"
                                                        }]
                                                    }]},
                                                quote_response={
                                                'test_response': True},
                                                quote_trace={}),
                "is_dpp_relevant": True
            },
            {
                "audit_document": AuditDocument(_id=str(uuid.uuid4()),
                                                tenant_id=self.tenant_id,
                                                correlation_id=self.correlation_id,
                                                creation=self.creation,
                                                quote_request={
                                                    "Party": [{
                                                        "taxRegistration": [{
                                                            "taxNumber": "y",
                                                            "taxNumberTypeCode": "isNaturalPerson"
                                                        }]
                                                    }]},
                                                quote_response={
                                                'test_response': True},
                                                quote_trace={}),
                "is_dpp_relevant": True
            },
            {
                "audit_document": AuditDocument(_id=str(uuid.uuid4()),
                                                tenant_id=self.tenant_id,
                                                correlation_id=self.correlation_id,
                                                creation=self.creation,
                                                quote_request={
                                                    "Party": [{
                                                        "taxRegistration": [{
                                                            "taxNumber": "N",
                                                            "taxNumberTypeCode": "isNaturalPerson"
                                                        }]
                                                    }]},
                                                quote_response={
                                                'test_response': True},
                                                quote_trace={}),
                "is_dpp_relevant": False
            },
            {
                "audit_document": AuditDocument(_id=str(uuid.uuid4()),
                                                tenant_id=self.tenant_id,
                                                correlation_id=self.correlation_id,
                                                creation=self.creation,
                                                quote_request={
                                                    "Party": [{
                                                        "taxRegistration": [{
                                                            "taxNumber": "Y",
                                                            "taxNumberTypeCode": "isNotNaturalPerson"
                                                        }]
                                                    }]},
                                                quote_response={
                                                'test_response': True},
                                                quote_trace={}),
                "is_dpp_relevant": False
            },
            {
                "audit_document": AuditDocument(_id=str(uuid.uuid4()),
                                                tenant_id=self.tenant_id,
                                                correlation_id=self.correlation_id,
                                                creation=self.creation,
                                                quote_request={
                                                    "Party": [{
                                                        "taxRegistration": [{
                                                            "taxNumberTypeCode": "isNotNaturalPerson"
                                                        }]
                                                    }]},
                                                quote_response={
                                                'test_response': True},
                                                quote_trace={}),
                "is_dpp_relevant": False
            },
            {
                "audit_document": AuditDocument(_id=str(uuid.uuid4()),
                                                tenant_id=self.tenant_id,
                                                correlation_id=self.correlation_id,
                                                creation=self.creation,
                                                quote_request={
                                                    "Party": [{
                                                        "taxRegistration": [{
                                                            "taxNumber": "Y"
                                                        }]
                                                    }]},
                                                quote_response={
                                                'test_response': True},
                                                quote_trace={}),
                "is_dpp_relevant": False
            },
            {
                "audit_document": AuditDocument(_id=str(uuid.uuid4()),
                                                tenant_id=self.tenant_id,
                                                correlation_id=self.correlation_id,
                                                creation=self.creation,
                                                quote_request={
                                                    "Party": [{
                                                        "taxRegistration": []
                                                    }]},
                                                quote_response={
                                                'test_response': True},
                                                quote_trace={}),
                "is_dpp_relevant": False
            },
            {
                "audit_document": AuditDocument(_id=str(uuid.uuid4()),
                                                tenant_id=self.tenant_id,
                                                correlation_id=self.correlation_id,
                                                creation=self.creation,
                                                quote_request={
                                                    "Party": []
                },
                    quote_response={
                    'test_response': True},
                    quote_trace={}),
                "is_dpp_relevant": False
            },
            {
                "audit_document": AuditDocument(_id=str(uuid.uuid4()),
                                                tenant_id=self.tenant_id,
                                                correlation_id=self.correlation_id,
                                                creation=self.creation,
                                                quote_request={},
                                                quote_response={
                                                'test_response': True},
                                                quote_trace={}),
                "is_dpp_relevant": False
            },
            {
                "audit_document": AuditDocument(_id=str(uuid.uuid4()),
                                                tenant_id=self.tenant_id,
                                                correlation_id=self.correlation_id,
                                                creation=self.creation,
                                                quote_request="not_a_dict_value",
                                                quote_response={
                                                'test_response': True},
                                                quote_trace={}),
                "is_dpp_relevant": False
            },
        ]

    def test_anonymize_payload_fields_GSSITAASHAL_1390(self):
        payload = self.create_anonymization_payload()
        anonymization_v0_service.anonymize_fields(payload['to_anonymize']['quoteRequest'])
        self.assertEqual(payload['to_anonymize'], payload['anonymized'])

    def create_anonymization_payload(self):
        return {
            "to_anonymize": {
                "quoteRequest": {
                    "Locations": [
                        {
                            "type": "SHIP_FROM",
                            "zipCode": "1234",
                            "addressLine1": "foo street",
                            "addressLine2": "foo street 2",
                            "addressLine3": "foo street 3"
                        },
                        {
                            "type": "CONTRACT_FROM",
                            "zipCode": "1234",
                            "addressLine1": "foo street",
                        },
                        {
                            "type": "SHIP_TO",
                            "zipCode": "4321"
                        }
                    ],
                    "Party": [
                        {
                            "role": "SHIP_FROM",
                            "taxRegistration": [
                                {
                                    "taxNumber": "Y",
                                    "taxNumberTypeCode": "isNaturalPerson"
                                },
                                {
                                    "taxNumber": "foo",
                                    "taxNumberTypeCode": "bar"
                                }
                            ]
                        },
                        {
                            "role": "CONTRACT_FROM",
                            "taxRegistration": [
                                {
                                    "taxNumber": "y",
                                    "taxNumberTypeCode": "isNaturalPerson"
                                },
                                {
                                    "taxNumber": "foo",
                                    "taxNumberTypeCode": "bar"
                                }
                            ]
                        },
                        {
                            "role": "CONTRACT_TO",
                            "taxRegistration": [
                                {
                                    "taxNumber": "y",
                                    "taxNumberTypeCode": "isNotNaturalPerson"
                                },
                                {
                                    "taxNumber": "foo",
                                    "taxNumberTypeCode": "bar"
                                }
                            ]
                        },
                        {
                            "role": "SHIP_TO",
                            "taxRegistration": [
                                {
                                    "taxNumber": "n",
                                    "taxNumberTypeCode": "isNaturalPerson"
                                },
                                {
                                    "taxNumber": "foo",
                                    "taxNumberTypeCode": "bar"
                                }
                            ]
                        }
                    ]
                }
            },
            "anonymized": {
                "quoteRequest": {
                    "Locations": [
                        {
                            "type": "SHIP_FROM",
                            "zipCode": anonymization_parameters.DATA_MASK,
                            "addressLine1": anonymization_parameters.DATA_MASK,
                            "addressLine2": anonymization_parameters.DATA_MASK,
                            "addressLine3": anonymization_parameters.DATA_MASK,
                        },
                        {
                            "type": "CONTRACT_FROM",
                            "zipCode": anonymization_parameters.DATA_MASK,
                            "addressLine1": anonymization_parameters.DATA_MASK,
                        },
                        {
                            "type": "SHIP_TO",
                            "zipCode": "4321"
                        }
                    ],
                    "Party": [
                        {
                            "role": "SHIP_FROM",
                            "taxRegistration": [
                                {
                                    "taxNumber": "Y",
                                    "taxNumberTypeCode": "isNaturalPerson"
                                },
                                {
                                    "taxNumber": anonymization_parameters.DATA_MASK,
                                    "taxNumberTypeCode": "bar"
                                }
                            ]
                        },
                        {
                            "role": "CONTRACT_FROM",
                            "taxRegistration": [
                                {
                                    "taxNumber": "y",
                                    "taxNumberTypeCode": "isNaturalPerson"
                                },
                                {
                                    "taxNumber": anonymization_parameters.DATA_MASK,
                                    "taxNumberTypeCode": "bar"
                                }
                            ]
                        },
                        {
                            "role": "CONTRACT_TO",
                            "taxRegistration": [
                                {
                                    "taxNumber": "y",
                                    "taxNumberTypeCode": "isNotNaturalPerson"
                                },
                                {
                                    "taxNumber": "foo",
                                    "taxNumberTypeCode": "bar"
                                }
                            ]
                        },
                        {
                            "role": "SHIP_TO",
                            "taxRegistration": [
                                {
                                    "taxNumber": "n",
                                    "taxNumberTypeCode": "isNaturalPerson"
                                },
                                {
                                    "taxNumber": "foo",
                                    "taxNumberTypeCode": "bar"
                                }
                            ]
                        }
                    ]
                }
            }
        }