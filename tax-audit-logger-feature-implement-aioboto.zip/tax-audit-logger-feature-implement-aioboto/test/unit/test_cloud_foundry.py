import unittest
from unittest.mock import MagicMock, Mock
from collections import namedtuple
from cfenv import AppEnv

from tax_audit_logger.environment.cloud_foundry import CloudFoundryEnvironment


class MainTest(unittest.TestCase):

    def test_get_object_store_credentials(self):
        AppEnv.get_service = MagicMock()
        cf_env = CloudFoundryEnvironment()
        cf_env.get_object_store_credentials()

        AppEnv.get_service.assert_called_once_with(label='objectstore')

    def test_get_object_store_credentials_from_user_provided(self):
        AppEnv.get_service = MagicMock()
        AppEnv.get_service.side_effect = Mock(side_effect=[Exception('mock exception'), 
                                              namedtuple('user_provided', {'credentials': {}})])
        cf_env = CloudFoundryEnvironment()
        cf_env.get_object_store_credentials()

        AppEnv.get_service.assert_called_with(label='user-provided')

    def test_get_rabbitmq_uri(self):
        AppEnv.get_service = MagicMock()
        cf_env = CloudFoundryEnvironment()
        cf_env.get_rabbitmq_uri()

        AppEnv.get_service.assert_called_once_with(label='rabbitmq')
