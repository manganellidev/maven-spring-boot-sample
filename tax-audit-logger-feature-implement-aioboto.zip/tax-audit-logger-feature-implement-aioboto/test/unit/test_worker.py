import aiormq
import json
import unittest
from unittest.mock import call, patch
from tax_audit_logger.communication import worker
from tax_audit_logger.environment.cloud_foundry import CloudFoundryEnvironment
from tax_audit_logger.logging.tax_logger import TaxLogger
from tax_audit_logger.persistence.audit_document import AuditDocument


class WorkerTest(unittest.IsolatedAsyncioTestCase):

    def setUp(self):
        self.properties = aiormq.spec.Basic.Properties(
            headers={'X-CorrelationID': b'fake_correlation_id'})
        self.properties_v0 = aiormq.spec.Basic.Properties(
            headers={
                'X-CorrelationID': b'fake_correlation_id',
                '__TypeId__': b'com.sap.slh.tax.maestro.api.v0.schema.AuditLogDocument'
            })
        self.body = json.loads(b'{"id":"1","tenantId":"123","quoteRequest":"request_123",'
                               b'"quoteResponse":"response_123","quoteTrace":{}}')
        self.audit_document = AuditDocument('1', '123', '321', '1900-01-01', {}, {}, {})

    @patch.object(TaxLogger, 'info')
    @patch.object(CloudFoundryEnvironment, "__init__", lambda x: None)
    @patch('tax_audit_logger.persistence.store.put_object')
    @patch('tax_audit_logger.environment.cloud_foundry.CloudFoundryEnvironment.get_object_store_credentials', return_value='credentials')
    @patch('tax_audit_logger.service.document_service.get_document_properties')
    @patch('tax_audit_logger.service.anonymization_service.should_be_anonymized', return_value=False)
    @patch('tax_audit_logger.service.validation_service.validate_message')
    @patch('tax_audit_logger.communication.worker._convert_message_to_audit_document')
    async def test_create_audit_document(self, mock_conversion, 
                                         mock_message_validator, mock_should_anonymize, 
                                         mock_document_service, mock_credentials,
                                         mock_obj_store_put_object, mock_tax_logger_info):
        mock_conversion.return_value = self.audit_document
        object_properties = {
            'name': 'some_name',
            'content': 'some_content'
        }
        mock_document_service.return_value = object_properties
        expected_info_message = f'Audit Document created: {object_properties["name"]}'

        await worker.create_audit_document(self.properties, self.body)
        mock_message_validator.assert_called_once_with(self.properties, self.body)
        mock_conversion.assert_called_once_with(self.properties, self.body)
        mock_should_anonymize.assert_called_once_with(self.audit_document)
        mock_document_service.assert_called_once_with(self.audit_document)
        mock_credentials.assert_called_once()
        mock_obj_store_put_object.assert_called_once_with(object_properties, 'credentials')
        mock_tax_logger_info.assert_called_once_with(expected_info_message)

    @patch.object(TaxLogger, 'info')
    @patch.object(CloudFoundryEnvironment, "__init__", lambda x: None)
    @patch('tax_audit_logger.persistence.store.put_object')
    @patch('tax_audit_logger.environment.cloud_foundry.CloudFoundryEnvironment.get_object_store_credentials', return_value='credentials')
    @patch('tax_audit_logger.service.document_service.get_document_properties')
    @patch('tax_audit_logger.service.anonymization_v0_service.should_be_anonymized', return_value=False)
    @patch('tax_audit_logger.service.validation_service.validate_message')
    @patch('tax_audit_logger.communication.worker._convert_message_to_audit_document')
    async def test_create_audit_document_v0(self, mock_conversion, 
                                      mock_message_validator, mock_should_anonymize, 
                                      mock_document_service, mock_credentials,
                                      mock_obj_store_put_object, mock_tax_logger_info):
        mock_conversion.return_value = self.audit_document
        object_properties = {
            'name': 'some_name',
            'content': 'some_content',
        }
        mock_document_service.return_value = object_properties
        expected_info_message = f'Audit Document created: {object_properties["name"]}'

        await worker.create_audit_document(self.properties_v0, self.body)
        mock_message_validator.assert_called_once_with(self.properties_v0, self.body)
        mock_conversion.assert_called_once_with(self.properties_v0, self.body)
        mock_should_anonymize.assert_called_once_with(self.audit_document)
        mock_document_service.assert_called_once_with(self.audit_document)
        mock_credentials.assert_called_once()
        mock_obj_store_put_object.assert_called_once_with(object_properties, 'credentials')
        mock_tax_logger_info.assert_called_once_with(expected_info_message)

    @patch.object(TaxLogger, 'info')
    @patch.object(CloudFoundryEnvironment, "__init__", lambda x: None)
    @patch('tax_audit_logger.persistence.store.put_object')
    @patch('tax_audit_logger.environment.cloud_foundry.CloudFoundryEnvironment.get_object_store_credentials', return_value='credentials')
    @patch('tax_audit_logger.service.anonymization_service.anonymize_fields')
    @patch('tax_audit_logger.service.document_service.get_document_properties')
    @patch('tax_audit_logger.service.document_service.get_document_properties_with_personal_data')
    @patch('tax_audit_logger.service.anonymization_service.should_be_anonymized', return_value=True)
    @patch('tax_audit_logger.service.validation_service.validate_message')
    @patch('tax_audit_logger.communication.worker._convert_message_to_audit_document')
    async def test_create_audit_document_anonymized(self, mock_conversion, 
                                                    mock_message_validator, mock_should_anonymize, 
                                                    mock_document_service_with_dpp, mock_document_service, 
                                                    mock_anonymize_fields, mock_credentials, 
                                                    mock_obj_store_put_object, mock_tax_logger_info):
        mock_conversion.return_value = self.audit_document
        object_properties = {
            'name': 'some_name',
            'content': 'some_content',
        }
        mock_document_service.return_value = object_properties
        mock_document_service_with_dpp.return_value = object_properties
        expected_info_message = f'Audit Document created: {object_properties["name"]}'

        await worker.create_audit_document(self.properties, self.body)
        mock_message_validator.assert_called_once_with(self.properties, self.body)
        mock_conversion.assert_called_once_with(self.properties, self.body)
        mock_should_anonymize.assert_called_once_with(self.audit_document)

        mock_document_service_with_dpp.assert_called_once_with(self.audit_document)
        mock_anonymize_fields.assert_called_once_with(self.audit_document.quote_request)
        mock_document_service.assert_called_once_with(self.audit_document)

        self.assertEqual(mock_credentials.call_count, 2)
        mock_obj_store_put_object.assert_has_calls([call(object_properties, 'credentials'), 
                                                    call(object_properties, 'credentials')])

        self.assertEqual(mock_tax_logger_info.call_count, 2)
        mock_tax_logger_info.assert_called_with(expected_info_message)

    @patch.object(TaxLogger, 'info')
    @patch.object(CloudFoundryEnvironment, "__init__", lambda x: None)
    @patch('tax_audit_logger.persistence.store.put_object')
    @patch('tax_audit_logger.environment.cloud_foundry.CloudFoundryEnvironment.get_object_store_credentials', return_value='credentials')
    @patch('tax_audit_logger.service.anonymization_v0_service.anonymize_fields')
    @patch('tax_audit_logger.service.document_service.get_document_properties')
    @patch('tax_audit_logger.service.document_service.get_document_properties_with_personal_data')
    @patch('tax_audit_logger.service.anonymization_v0_service.should_be_anonymized', return_value=True)
    @patch('tax_audit_logger.service.validation_service.validate_message')
    @patch('tax_audit_logger.communication.worker._convert_message_to_audit_document')
    async def test_create_audit_document_v0_anonymized_GSSITAASHAL_1249_GSSITAASHAL_1390(self, mock_conversion, 
                                                    mock_message_validator, mock_should_anonymize, 
                                                    mock_document_service_with_dpp, mock_document_service, 
                                                    mock_anonymize_fields, mock_credentials, 
                                                    mock_obj_store_put_object, mock_tax_logger_info):
        mock_conversion.return_value = self.audit_document
        object_properties = {
            'name': 'some_name',
            'content': 'some_content',
        }
        mock_document_service.return_value = object_properties
        mock_document_service_with_dpp.return_value = object_properties
        expected_info_message = f'Audit Document created: {object_properties["name"]}'

        await worker.create_audit_document(self.properties_v0, self.body)
        mock_message_validator.assert_called_once_with(self.properties_v0, self.body)
        mock_conversion.assert_called_once_with(self.properties_v0, self.body)
        mock_should_anonymize.assert_called_once_with(self.audit_document)

        mock_document_service_with_dpp.assert_called_once_with(self.audit_document)
        mock_anonymize_fields.assert_called_once_with(self.audit_document.quote_request)
        mock_document_service.assert_called_once_with(self.audit_document)

        self.assertEqual(mock_credentials.call_count, 2)
        mock_obj_store_put_object.assert_has_calls([call(object_properties, 'credentials'), 
                                                    call(object_properties, 'credentials')])

        self.assertEqual(mock_tax_logger_info.call_count, 2)
        mock_tax_logger_info.assert_called_with(expected_info_message)

    def test_convert_to_audit_document_GSSITAASHAL_1249(self):
        audit_document = worker._convert_message_to_audit_document(self.properties, self.body)
        self.assertTrue(audit_document)

    @patch('tax_audit_logger.communication.worker._generate_unique_id', return_value='1')
    def test_generate_correlation_id(self, mock_generate_unique_id):
        actual_id = worker._generate_unique_id()
        expected_id = '1'
        self.assertEqual(actual_id, expected_id)
        mock_generate_unique_id.assert_called_once()
