import dataclasses
import json
import unittest
import uuid

from datetime import datetime

from tax_audit_logger.persistence.audit_document import AuditDocument
from tax_audit_logger.service import document_service


class DocumentServiceTest(unittest.TestCase):

    def setUp(self):
        self.tenant_id = str(uuid.uuid4())
        self.correlation_id = str(uuid.uuid4())
        self.creation = str(datetime.utcnow().isoformat())
        self.audit_document = AuditDocument(_id=str(uuid.uuid4()),
                                            tenant_id=self.tenant_id,
                                            correlation_id=self.correlation_id,
                                            creation=self.creation,
                                            quote_request={'test_request': True},
                                            quote_response={'test_response': True},
                                            quote_trace={})

    def test_document_properties_creation(self):
        document = dataclasses.asdict(self.audit_document)
        expected_document_name = f"{self.tenant_id}/{self.creation}_{self.correlation_id}"
        expected_document_content = json.dumps(document).encode('utf-8')
        expected_document_properties = {
            'name': expected_document_name,
            'content': expected_document_content,
        }
        actual_document_properties = document_service.get_document_properties(self.audit_document)
        self.assertEqual(actual_document_properties['name'], expected_document_properties['name'],
                         "The document does not match the expected")
        self.assertEqual(actual_document_properties['content'],
                         expected_document_properties['content'],
                         "The document content does not match the expected")

    def test_document_properties_creation_with_personal_data(self):
        document = dataclasses.asdict(self.audit_document)
        expected_document_name = f"{self.tenant_id}/!dpp/{self.creation}_{self.correlation_id}"
        expected_document_content = json.dumps(document).encode('utf-8')
        expected_document_properties = {
            'name': expected_document_name,
            'content': expected_document_content,
        }
        actual_document_properties = document_service.get_document_properties_with_personal_data(self.audit_document)
        self.assertEqual(actual_document_properties['name'], expected_document_properties['name'],
                         "The document does not match the expected")
        self.assertEqual(actual_document_properties['content'],
                         expected_document_properties['content'],
                         "The document content does not match the expected")
