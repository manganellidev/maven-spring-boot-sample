import asyncio
import unittest
from unittest.mock import patch
from tax_audit_logger import main
from tax_audit_logger.environment.cloud_foundry import CloudFoundryEnvironment
from tax_audit_logger.logging.tax_logger import TaxLogger

class MainTest(unittest.IsolatedAsyncioTestCase):

    def setUp(self):
        self.event_loop = asyncio.get_event_loop()

    @patch.object(CloudFoundryEnvironment, "__init__", lambda x: None)
    @patch('tax_audit_logger.main.CloudFoundryEnvironment.get_rabbitmq_uri', return_value='fake uri')
    @patch('tax_audit_logger.main.create_channel', return_value='fake channel')
    @patch('tax_audit_logger.main.configure_queue', return_value='fake queue')
    @patch('tax_audit_logger.main.start_consuming_queue')
    async def test_main(self, mock_start_consuming, mock_configure_queue, mock_create_channel,
                  mock_get_rabbit_uri):
        await main.main(self.event_loop)
        mock_get_rabbit_uri.assert_called_once()
        mock_create_channel.assert_called_once_with('fake uri', self.event_loop)
        mock_configure_queue.assert_called_once_with('fake channel')
        mock_start_consuming.assert_called_once_with('fake queue')

    @patch.object(TaxLogger, 'error')
    @patch.object(CloudFoundryEnvironment, "__init__", lambda x: None)
    @patch('tax_audit_logger.main.CloudFoundryEnvironment.get_rabbitmq_uri', side_effect=RuntimeError)
    @patch('tax_audit_logger.main.create_channel')
    @patch('tax_audit_logger.main.configure_queue')
    @patch('tax_audit_logger.main.start_consuming_queue')
    @patch('tax_audit_logger.main._restart_after_cool_down')
    async def test_exception_get_rabbit_mq_credentials_GSSITAASHAL_1251(self, mock_restart,
                                                                        mock_start_consuming, mock_configure_queue,
                                                                        mock_create_channel, mock_get_rabbit_uri,
                                                                        mock_tax_logger_error):
        await main.main(self.event_loop)
        mock_get_rabbit_uri.assert_called_once()
        mock_create_channel.assert_not_called()
        mock_configure_queue.assert_not_called()
        mock_start_consuming.assert_not_called()
        mock_tax_logger_error.assert_called()
        mock_restart.assert_called_once_with(60)

    @patch.object(TaxLogger, 'error')
    @patch.object(CloudFoundryEnvironment, "__init__", lambda x: None)
    @patch('tax_audit_logger.main.CloudFoundryEnvironment.get_rabbitmq_uri', return_value='fake uri')
    @patch('tax_audit_logger.main.create_channel', side_effect=RuntimeError)
    @patch('tax_audit_logger.main.configure_queue')
    @patch('tax_audit_logger.main.start_consuming_queue')
    @patch('tax_audit_logger.main._restart_after_cool_down')
    async def test_exception_create_channel_GSSITAASHAL_1251(self, mock_restart, mock_start_consuming,
                                                       mock_configure_queue, mock_create_channel,
                                                       mock_get_rabbit_uri, mock_tax_logger_error):
        await main.main(self.event_loop)
        mock_get_rabbit_uri.assert_called_once()
        mock_create_channel.assert_called_once_with('fake uri', self.event_loop)
        mock_configure_queue.assert_not_called()
        mock_start_consuming.assert_not_called()
        mock_tax_logger_error.assert_called()
        mock_restart.assert_called_once_with(60)

    @patch.object(TaxLogger, 'error')
    @patch.object(CloudFoundryEnvironment, "__init__", lambda x: None)
    @patch('tax_audit_logger.main.CloudFoundryEnvironment.get_rabbitmq_uri', return_value='fake uri')
    @patch('tax_audit_logger.main.create_channel', return_value='fake channel')
    @patch('tax_audit_logger.main.configure_queue', side_effect=RuntimeError)
    @patch('tax_audit_logger.main.start_consuming_queue')
    @patch('tax_audit_logger.main._restart_after_cool_down')
    async def test_exception_configure_queue_GSSITAASHAL_1251(self, mock_restart, mock_start_consuming,
                                                              mock_configure_queue, mock_create_channel,
                                                              mock_get_rabbit_uri, mock_tax_logger_error):
        await main.main(self.event_loop)
        mock_get_rabbit_uri.assert_called_once()
        mock_create_channel.assert_called_with('fake uri', self.event_loop)
        mock_configure_queue.assert_called_once_with('fake channel')
        mock_start_consuming.assert_not_called()
        mock_tax_logger_error.assert_called()
        mock_restart.assert_called_once_with(60)

    @patch.object(TaxLogger, 'error')
    @patch.object(CloudFoundryEnvironment, "__init__", lambda x: None)
    @patch('tax_audit_logger.main.CloudFoundryEnvironment.get_rabbitmq_uri', side_effect=TypeError)
    @patch('tax_audit_logger.main._restart_after_cool_down')
    async def test_fake_exception_TypeError_GSSITAASHAL_1251(self, mock_restart, mock_get_rabbit_uri,
                                                       mock_tax_logger_error):
        await main.main(self.event_loop)
        mock_get_rabbit_uri.assert_called_once()
        mock_tax_logger_error.assert_called()
        mock_restart.assert_called_once_with(60)

    @patch('tax_audit_logger.main.main')
    @patch('tax_audit_logger.main.sleep')
    async def test_restart_after_cool_down(self, mock_sleep, mock_main):
        await main._restart_after_cool_down(1)
        mock_sleep.assert_called_once_with(1)
        mock_main.assert_called_once()
