import unittest
from collections import namedtuple
from unittest.mock import patch

from tax_audit_logger.service import validation_service
from tax_audit_logger.logging.tax_logger import TaxLogger


class WorkerTest(unittest.TestCase):

    @patch('tax_audit_logger.service.validation_service._validate_message_payload')
    @patch('tax_audit_logger.service.validation_service._validate_message_headers')
    def test_validate_message_GSSITAASHAL_1251(self, mock_validate_headers, mock_validate_payload):
        properties = {'headers': {'X-CorrelationID': b'some_correlation_id'}}
        payload = {'quoteRequest': {}, 'quoteResponse': {}, 'quoteTrace': {}, 'tenantId': 'some_tenant'}

        validation_service.validate_message(properties, payload)
        mock_validate_headers.assert_called_once_with(properties)
        mock_validate_payload.assert_called_once_with(payload)

    def test_handle_message_headers_with_correlation_GSSITAASHAL_1251(self):
        property_type = namedtuple('Properties', ['headers'])
        original_properties = property_type(headers={'X-CorrelationID': b'123'})
        expected_properties = property_type(headers={'X-CorrelationID': '123'})

        validation_service._validate_message_headers(original_properties)
        self.assertEqual(original_properties, expected_properties)

    @patch.object(TaxLogger, 'warn')
    @patch('tax_audit_logger.service.validation_service._generate_unique_id', return_value='123')
    def test_handle_message_headers_no_correlation_GSSITAASHAL_1251(self, mock_generate_uuid,
                                                                                     mock_tax_logger_warn):
        property_type = namedtuple('Properties', ['headers'])
        original_properties = property_type(headers={'X-CorrelationID': None})
        expected_properties = property_type(headers={'X-CorrelationID': '123'})
        expected_warn_message = f'The "X-correlationID" header was not informed in the message. ' \
                                f'Correlation ID {mock_generate_uuid.return_value} was created for your transaction.'

        validation_service._validate_message_headers(original_properties)
        mock_generate_uuid.assert_called_once()
        mock_tax_logger_warn.assert_called_once_with(expected_warn_message)
        self.assertEqual(original_properties, expected_properties)

    def test_validate_message_payload_success_GSSITAASHAL_1251(self):
        try:
            valid_payload = {'quoteRequest': {}, 'quoteResponse': {}, 'quoteTrace': {}, 'tenantId': 'some_tenant'}
            validation_service._validate_message_payload(valid_payload)
        except ValueError as ex:
            self.fail(f'The contract was violated: {str(ex)}')

    def test_validate_message_payload_failure_GSSITAASHAL_1251(self):
        invalid_payloads = self._create_message_payloads_for_failure()

        for payload in invalid_payloads:
            self.assertRaises(ValueError, lambda: validation_service._validate_message_payload(payload))

    def _create_message_payloads_for_failure(self):
        return [
            {'quoteRequest': {}, 'quoteResponse': {}, 'quoteTrace': {}, 'tenantId': None},
            {'quoteRequest': {}, 'quoteResponse': {}, 'quoteTrace': None, 'tenantId': 'some_tenant'},
            {'quoteRequest': {}, 'quoteResponse': None, 'quoteTrace': {}, 'tenantId': 'some_tenant'},
            {'quoteRequest': None, 'quoteResponse': {}, 'quoteTrace': {}, 'tenantId': 'some_tenant'},
            {'quoteRequest': None, 'quoteResponse': None, 'quoteTrace': {}, 'tenantId': 'some_tenant'},
            {'quoteRequest': None, 'quoteResponse': {}, 'quoteTrace': None, 'tenantId': 'some_tenant'},
            {'quoteRequest': None, 'quoteResponse': {}, 'quoteTrace': {}, 'tenantId': None},
            {'quoteRequest': {}, 'quoteResponse': None, 'quoteTrace': None, 'tenantId': 'some_tenant'},
            {'quoteRequest': {}, 'quoteResponse': None, 'quoteTrace': {}, 'tenantId': None},
            {'quoteRequest': {}, 'quoteResponse': {}, 'quoteTrace': None, 'tenantId': None},
            {'quoteRequest': None, 'quoteResponse': None, 'quoteTrace': None, 'tenantId': 'some_tenant'},
            {'quoteRequest': None, 'quoteResponse': None, 'quoteTrace': {}, 'tenantId': None},
            {'quoteRequest': None, 'quoteResponse': {}, 'quoteTrace': None, 'tenantId': None},
            {'quoteRequest': {}, 'quoteResponse': None, 'quoteTrace': None, 'tenantId': None},
            {'quoteRequest': None, 'quoteResponse': None, 'quoteTrace': None, 'tenantId': None},
            {'quoteRequest': {}, 'quoteResponse': {}, 'quoteTrace': {}},
            {'quoteRequest': {}, 'quoteResponse': {}, 'tenantId': 'some_tenant'},
            {'quoteRequest': {}, 'quoteTrace': {}, 'tenantId': 'some_tenant'},
            {'quoteResponse': {}, 'quoteTrace': {}, 'tenantId': 'some_tenant'},
            {'quoteRequest': {}, 'quoteResponse': {}},
            {'quoteRequest': {}, 'quoteTrace': {}},
            {'quoteRequest': {}, 'tenantId': 'some_tenant'},
            {'quoteResponse': {}, 'quoteTrace': {}},
            {'quoteResponse': {}, 'tenantId': 'some_tenant'},
            {'quoteTrace': {}, 'tenantId': 'some_tenant'},
            {'quoteRequest': {}},
            {'quoteResponse': {}},
            {'quoteTrace': {}},
            {'tenantId': 'some_tenant'},
            {}
        ]
    
    @patch('tax_audit_logger.service.validation_service._generate_unique_id', return_value='1')
    def test_generate_correlation_id(self, mock_generate_unique_id):
        actual_id = validation_service._generate_unique_id()
        expected_id = '1'
        self.assertEqual(actual_id, expected_id)
        mock_generate_unique_id.assert_called_once()
