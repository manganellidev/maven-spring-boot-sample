import unittest
import uuid
from datetime import datetime
from unittest.mock import patch

from tax_audit_logger.persistence.audit_document import AuditDocument
from tax_audit_logger.persistence import store
from tax_audit_logger.logging.tax_logger import TaxLogger


class StoreTest(unittest.IsolatedAsyncioTestCase):

    def setUp(self):
        self.credentials = {
            'host': "some_host",
            'access_key_id': "some_access_key_id",
            'secret_access_key': "some_secret_access_key",
            'region': "some_region",
            'bucket': "some_bucket"
        }
        self.tenant_id = str(uuid.uuid4())
        self.correlation_id = str(uuid.uuid4())
        self.creation = str(datetime.utcnow().isoformat())
        self.audit_document = AuditDocument(_id=str(uuid.uuid4()),
                                            tenant_id=self.tenant_id,
                                            correlation_id=self.correlation_id,
                                            creation=self.creation,
                                            quote_request={
                                                'test_request': True},
                                            quote_response={
                                                'test_response': True},
                                            quote_trace={})

    @patch('tax_audit_logger.persistence.store.aioboto3')
    async def test_put_object(self, mock_aioboto):
        document_properties = {
            'name': 'some_name',
            'content': 'some_content',
        }
        await store.put_object(document_properties, self.credentials)
        mock_aioboto.client.assert_called_once_with('s3',
                                                    aws_access_key_id=self.credentials['access_key_id'],
                                                    aws_secret_access_key=self.credentials['secret_access_key'],
                                                    region_name=self.credentials['region'])
        mock_aioboto.client.return_value.__aenter__.return_value.put_object.assert_called_once_with(
            Bucket=self.credentials['bucket'],
            Body=document_properties['content'],
            Key=document_properties['name']
        )
