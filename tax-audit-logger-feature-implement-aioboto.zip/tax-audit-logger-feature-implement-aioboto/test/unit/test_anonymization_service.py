import dataclasses
import io
import json
import unittest
import uuid

from datetime import datetime

from tax_audit_logger.persistence.audit_document import AuditDocument
from tax_audit_logger.service import anonymization_service, anonymization_parameters


class AnonymizationServiceTest(unittest.TestCase):

    def setUp(self):
        self.tenant_id = str(uuid.uuid4())
        self.correlation_id = str(uuid.uuid4())
        self.creation = str(datetime.utcnow().isoformat())

    def test_should_anonymize_fields_GSSITAASHAL_1363(self):
        for combination in self.create_audit_document_combinations():
            should_be_anonymized = anonymization_service.should_be_anonymized(
                combination['audit_document'])
            self.assertEqual(should_be_anonymized, combination['is_dpp_relevant'],
                             "The document does not match the expected")

    def create_audit_document_combinations(self):
        return [
            {
                "audit_document": AuditDocument(_id=str(uuid.uuid4()),
                                                tenant_id=self.tenant_id,
                                                correlation_id=self.correlation_id,
                                                creation=self.creation,
                                                quote_request={
                                                    "parties": [{"isNaturalPerson": True}]},
                                                quote_response={
                                                'test_response': True},
                                                quote_trace={}),
                "is_dpp_relevant": True
            },
            {
                "audit_document": AuditDocument(_id=str(uuid.uuid4()),
                                                tenant_id=self.tenant_id,
                                                correlation_id=self.correlation_id,
                                                creation=self.creation,
                                                quote_request={
                                                    "parties": [{"isNaturalPerson": False}]},
                                                quote_response={
                                                'test_response': True},
                                                quote_trace={}),
                "is_dpp_relevant": False
            },
            {
                "audit_document": AuditDocument(_id=str(uuid.uuid4()),
                                                tenant_id=self.tenant_id,
                                                correlation_id=self.correlation_id,
                                                creation=self.creation,
                                                quote_request={
                                                    "parties": []},
                                                quote_response={
                                                'test_response': True},
                                                quote_trace={}),
                "is_dpp_relevant": False
            },
            {
                "audit_document": AuditDocument(_id=str(uuid.uuid4()),
                                                tenant_id=self.tenant_id,
                                                correlation_id=self.correlation_id,
                                                creation=self.creation,
                                                quote_request={},
                                                quote_response={
                                                'test_response': True},
                                                quote_trace={}),
                "is_dpp_relevant": False
            },
            {
                "audit_document": AuditDocument(_id=str(uuid.uuid4()),
                                                tenant_id=self.tenant_id,
                                                correlation_id=self.correlation_id,
                                                creation=self.creation,
                                                quote_request="not_a_dict_value",
                                                quote_response={
                                                'test_response': True},
                                                quote_trace={}),
                "is_dpp_relevant": False
            },
        ]

    def test_anonymize_payload_fields_GSSITAASHAL_1363(self):
        payload = self.create_anonymization_payload()
        anonymization_service.anonymize_fields(payload['to_anonymize']['quoteRequest'])
        self.assertEqual(payload['to_anonymize'], payload['anonymized'])

    def create_anonymization_payload(self):
        return {
            "to_anonymize": {
                "quoteRequest": {
                    "parties": [
                        {
                            "address": "foo street",
                            "zipCode": "1234",
                            "isNaturalPerson": True,
                            "taxRegistrations": [
                                {
                                    "type": "CPF",
                                    "number": "111.111.111-11"
                                },
                                {
                                    "type": "CPF",
                                    "number": "222.222.222-22"
                                }
                            ]
                        },
                        {
                            "isNaturalPerson": True,
                            "taxRegistrations": [
                                {
                                    "type": "CPF",
                                }
                            ]
                        },
                        {
                            "address": "foo street",
                            "zipCode": "1234",
                            "isNaturalPerson": False,
                            "taxRegistrations": [
                                {
                                    "type": "CPF",
                                    "number": "111.111.111-11"
                                }
                            ]
                        },
                        {
                            "address": "foo street",
                            "zipCode": "1234",
                            "taxRegistrations": [
                                {
                                    "type": "CPF",
                                    "number": "111.111.111-11"
                                }
                            ]
                        },
                    ]
                }
            },
            "anonymized": {
                "quoteRequest": {
                    "parties": [
                        {
                            "address": anonymization_parameters.DATA_MASK,
                            "zipCode": anonymization_parameters.DATA_MASK,
                            "isNaturalPerson": True,
                            "taxRegistrations": [
                                {
                                    "type": "CPF",
                                    "number": anonymization_parameters.DATA_MASK
                                },
                                {
                                    "type": "CPF",
                                    "number": anonymization_parameters.DATA_MASK
                                }
                            ]
                        },
                        {
                            "isNaturalPerson": True,
                            "taxRegistrations": [
                                {
                                    "type": "CPF",
                                }
                            ]
                        },
                        {
                            "address": "foo street",
                            "zipCode": "1234",
                            "isNaturalPerson": False,
                            "taxRegistrations": [
                                {
                                    "type": "CPF",
                                    "number": "111.111.111-11"
                                }
                            ]
                        },
                        {
                            "address": "foo street",
                            "zipCode": "1234",
                            "taxRegistrations": [
                                {
                                    "type": "CPF",
                                    "number": "111.111.111-11"
                                }
                            ]
                        },
                    ]
                }
            }
        }
