import aio_pika
import asyncio
import json
import unittest
from collections import namedtuple
from unittest.mock import AsyncMock, Mock, patch, MagicMock
from tax_audit_logger.communication.parameters import QUEUE, EXCHANGE
from tax_audit_logger.communication.setup import create_channel, configure_queue, start_consuming_queue, \
    _process_message_callback
from tax_audit_logger.logging.tax_logger import TaxLogger


class SetupTest(unittest.IsolatedAsyncioTestCase):

    def setUp(self):
        self.event_loop = asyncio.get_event_loop()

    @patch('tax_audit_logger.communication.setup.aio_pika.connect_robust')
    async def test_create_channel(self, mock_connect_robust):
        mock_connect_robust.return_value.channel.return_value = 'fake channel'
        
        channel = await create_channel('fake uri', self.event_loop)
        self.assertEqual(channel, 'fake channel')
        mock_connect_robust.assert_called_once_with('fake uri', loop=self.event_loop)
        mock_connect_robust.return_value.channel.assert_called_once()

    @patch('tax_audit_logger.communication.setup.aio_pika.connect_robust', side_effect=Exception)
    async def test_exception_create_channel(self, mock_connect_robust):
        with self.assertRaises(Exception):
            await create_channel('fake uri', self.event_loop)
        mock_connect_robust.assert_called_once_with('fake uri', loop=self.event_loop)
        mock_connect_robust.return_value.channel.assert_not_called()

    async def test_configure_queue(self):
        channel = AsyncMock()
        await configure_queue(channel)

        channel.declare_queue.assert_called_once_with(name=QUEUE, durable=True, auto_delete=False)
        channel.set_qos.assert_called_once_with(prefetch_count=100)
        channel.declare_exchange.assert_called_once_with(name=EXCHANGE, durable=True, type=aio_pika.ExchangeType.FANOUT)
        channel.declare_queue.return_value.bind.assert_called_once_with(exchange=EXCHANGE)

    async def test_exception_configure_queue(self):
        mock_channel = AsyncMock()
        mock_channel.declare_queue = AsyncMock(side_effect=Exception)
        
        with self.assertRaises(Exception):
            await configure_queue(mock_channel)
        mock_channel.declare_queue.assert_called_once_with(name=QUEUE, durable=True, auto_delete=False)
        mock_channel.set_qos.assert_not_called()
        mock_channel.declare_exchange.assert_not_called()
        mock_channel.declare_queue.return_value.bind.assert_not_called()

    async def test_start_consuming_queue(self):
        mock_queue = AsyncMock()
        await start_consuming_queue(mock_queue)
        mock_queue.consume.assert_called_once_with(_process_message_callback)

    @patch('tax_audit_logger.communication.setup.create_audit_document')
    async def test_process_message_callback(self, mock_create_audit_document):
        mock_message = AsyncMock()
        mock_message.process = MagicMock()
        mock_message.properties = 'properties'
        mock_message.body = b'{ "body": "success" }'

        await _process_message_callback(mock_message)
        mock_message.process.assert_called_once()
        mock_create_audit_document.assert_called_once_with(mock_message.properties, json.loads(mock_message.body))

    @patch.object(TaxLogger, 'error')
    @patch('tax_audit_logger.communication.setup.create_audit_document', side_effect=TypeError('error'))
    async def test_error_when_processing_message(self, mock_create_audit_document,
                                                 mock_logger):
        property_type = namedtuple('Properties', ['headers'])
        
        mock_message = AsyncMock()
        mock_message.process = MagicMock()
        mock_message.properties =  property_type(headers={'X-CorrelationID': '123'})
        mock_message.body = b'{ "body": "success" }'

        expected_error = 'An error has occurred when saving log with correlation ID {}. ' \
                         'Error was: {}'.format(mock_message.properties.headers['X-CorrelationID'],
                                                'error')
        await _process_message_callback(mock_message)
        mock_create_audit_document.assert_called_once_with(mock_message.properties, json.loads(mock_message.body))
        mock_logger.assert_called_once_with(expected_error)
