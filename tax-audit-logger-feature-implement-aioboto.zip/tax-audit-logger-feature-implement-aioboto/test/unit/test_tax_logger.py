import unittest

from unittest.mock import patch, MagicMock, call

from tax_audit_logger.logging.tax_logger import TaxLogger


class TaxLoggerTest(unittest.TestCase):
    log = TaxLogger()

    @patch.object(TaxLogger, '_generate_correlation_id')
    @patch('tax_audit_logger.logging.tax_logger.cf_logging')
    def test_parameterized_log_when_a_new_correlation_id_is_not_created_GSSITAASHAL_1250(self, cf_logging_mock,
                                                                                         generate_correlation_id_mock):
        cf_logging_mock.FRAMEWORK.context.set_correlation_id = MagicMock()
        params_list = [
            ['INFO', "Log message for info", '123', False, [call('123'), call('')]],
            ['INFO', "Log message for info", '123', True, [call('123'), call('')]],
            ['INFO', "Log message for info", '', False, [call('')]],
            ['INFO', "Log message for info", None, False, [call('')]],
            ['WARNING', "Log message for warn", '123', False, [call('123'), call('')]],
            ['WARNING', "Log message for warn", '123', True, [call('123'), call('')]],
            ['WARNING', "Log message for warn", '', False, [call('')]],
            ['WARNING', "Log message for warn", None, False, [call('')]],
            ['ERROR', "Log message for error", '123', False, [call('123'), call('')]],
            ['ERROR', "Log message for error", '123', True, [call('123'), call('')]],
            ['ERROR', "Log message for error", '', False, [call('')]],
            ['ERROR', "Log message for error", None, False, [call('')]]
        ]
        for log_level, message, correlation_id, new_correlation_id, set_correlation_id_calls in params_list:
            with self.assertLogs(level=log_level) as cm:
                if log_level == 'INFO':
                    self.log.info(message, correlation_id, new_correlation_id)
                    self.assertEqual(cm.output, ["INFO:cli.logger:Log message for info"])
                elif log_level == 'WARNING':
                    self.log.warn(message, correlation_id, new_correlation_id)
                    self.assertEqual(cm.output, ["WARNING:cli.logger:Log message for warn"])
                elif log_level == 'ERROR':
                    self.log.error(message, correlation_id, new_correlation_id)
                    self.assertEqual(cm.output, ["ERROR:cli.logger:Log message for error"])
            generate_correlation_id_mock.assert_not_called()
            cf_logging_mock.FRAMEWORK.context.set_correlation_id.assert_has_calls(set_correlation_id_calls)

    @patch.object(TaxLogger, '_generate_correlation_id', return_value='123')
    @patch('tax_audit_logger.logging.tax_logger.cf_logging')
    def test_parameterized_log_when_correlation_id_is_default_and_new_one_shall_be_provided_GSSITAASHAL_1250(self, cf_logging_mock,
                                                                                                             generate_correlation_id_mock):
        cf_logging_mock.FRAMEWORK.context.set_correlation_id = MagicMock()
        params_list = [
            ['INFO', "Log message for info", None, True, [call('123'), call('')]],
            ['WARNING', "Log message for warn", None, True, [call('123'), call('')]],
            ['ERROR', "Log message for error", None, True, [call('123'), call('')]],
        ]
        for log_level, message, correlation_id, new_correlation_id, set_correlation_id_calls in params_list:
            with self.assertLogs(level=log_level) as cm:
                if log_level == 'INFO':
                    self.log.info(message, correlation_id, new_correlation_id)
                    self.assertEqual(cm.output, ["INFO:cli.logger:Log message for info"])
                elif log_level == 'WARNING':
                    self.log.warn(message, correlation_id, new_correlation_id)
                    self.assertEqual(cm.output, ["WARNING:cli.logger:Log message for warn"])
                elif log_level == 'ERROR':
                    self.log.error(message, correlation_id, new_correlation_id)
                    self.assertEqual(cm.output, ["ERROR:cli.logger:Log message for error"])
            generate_correlation_id_mock.assert_called()
            cf_logging_mock.FRAMEWORK.context.set_correlation_id.assert_has_calls(set_correlation_id_calls)

    @patch('tax_audit_logger.logging.tax_logger.uuid4', return_value=1)
    def test_generate_correlation_id_GSSITAASHAL_1250(self, mock_uuid):
        actual_id = self.log._generate_correlation_id()
        expected_id = '1'
        self.assertEqual(actual_id, expected_id)
        mock_uuid.assert_called_once()
