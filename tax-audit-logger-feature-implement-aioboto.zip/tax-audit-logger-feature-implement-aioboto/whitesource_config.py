import setup

# configuration for Whitesource
config_info = {
    'product_name': 'SHC - SLHTAX-TAX AUDIT LOGGER 200',
    'check_policies': True,
    'force_check_all_dependencies': True,
    'force_update': True,
    'proxy': {'host': 'proxy.wdf.sap.corp', 'port': '8080', 'username': '', 'password': ''}
}