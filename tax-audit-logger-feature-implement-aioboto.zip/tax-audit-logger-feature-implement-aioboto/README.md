# Tax Audit Logger

## Pipeline Status

### Dev branch
[![Pipeline Status](https://gketaas.jaas-gcp.cloud.sap.corp/job/taasCF/job/tax-audit-logger/job/dev/badge/icon?subject=pipeline)](https://gketaas.jaas-gcp.cloud.sap.corp/job/taasCF/job/tax-audit-logger/job/dev/)
[![CI Build Status](https://prod-build10000.wdf.sap.corp/job/tax-service/job/tax-service-tax-audit-logger-SP-MS-common/badge/icon?subject=build)](https://prod-build10000.wdf.sap.corp/job/tax-service/job/tax-service-tax-audit-logger-SP-MS-common/)
[![PERF Tests](https://gketaas.jaas-gcp.cloud.sap.corp/job/taasCF/job/tax-audit-logger/job/dev/badge/icon?subject=perf%20tests)](https://gketaas.jaas-gcp.cloud.sap.corp/job/taasCF/job/tax-audit-logger/job/dev/perf-tests_20target-newman-perf-tests_2ehtml/)
[![PPMS](https://gketaas.jaas-gcp.cloud.sap.corp/job/taasCF/job/tax-audit-logger/job/dev/badge/icon?subject=ppms)](https://gketaas.jaas-gcp.cloud.sap.corp/job/taasCF/job/tax-audit-logger/job/dev/PPMS_20Compliance_20Check_20Report/)
[![Quality Gate](https://sonarci.wdf.sap.corp:8443/sonar/api/badges/gate?key=tax_audit_logger-dev)](https://sonarci.wdf.sap.corp:8443/sonar/dashboard?id=tax_audit_logger-dev)
[![Tests](https://sonarci.wdf.sap.corp:8443/sonar/api/badges/measure?key=tax_audit_logger-dev&metric=tests)](https://sonarci.wdf.sap.corp:8443/sonar/component_measures?id=tax_audit_logger-dev&metric=tests)
[![Coverage](https://sonarci.wdf.sap.corp:8443/sonar/api/badges/measure?key=tax_audit_logger-dev&metric=coverage)](https://sonarci.wdf.sap.corp:8443/sonar/component_measures?id=tax_audit_logger-dev&metric=Coverage)
[![Bugs](https://sonarci.wdf.sap.corp:8443/sonar/api/badges/measure?key=tax_audit_logger-dev&metric=bugs)](https://sonarci.wdf.sap.corp:8443/sonar/project/issues?id=tax_audit_logger-dev&resolved=false&types=BUG)
[![Vulnerabilities](https://sonarci.wdf.sap.corp:8443/sonar/api/badges/measure?key=tax_audit_logger-dev&metric=vulnerabilities)](https://sonarci.wdf.sap.corp:8443/sonar/project/issues?id=tax_audit_logger-dev&resolved=false&types=VULNERABILITY)
[![Code Smells](https://sonarci.wdf.sap.corp:8443/sonar/api/badges/measure?key=tax_audit_logger-dev&metric=code_smells)](https://sonarci.wdf.sap.corp:8443/sonar/project/issues?id=tax_audit_logger-dev&resolved=false&types=CODE_SMELL)

### Results
- [Sonar](https://sonarci.wdf.sap.corp:8443/sonar/dashboard?id=tax_audit_logger-dev)
- [Checkmarx](https://cx.wdf.sap.corp/CxWebClient/portal#/projectState/83060/Summary)
- [PPMS](https://gketaas.jaas-gcp.cloud.sap.corp/job/taasCF/job/tax-audit-logger/job/dev/PPMS_20Compliance_20Check_20Report/)
- [PERF Tests](https://gketaas.jaas-gcp.cloud.sap.corp/job/taasCF/job/tax-audit-logger/job/dev/perf-tests_20target-newman-perf-tests_2ehtml/)

## Getting started
* Clone the project
* Create a virtual environment with ```python -m venv ./venv``` on the project folder 
* Activate the virtual environment with ```.\venv\Scripts\activate```
    * This command will create a virtual environment for this project and it will allow you to run the dependencies locally instead to force you to install them globally
    * It's possible to deactivate the virtual environment with the command ```deactivate```, after to finish your local tests
* Install all project dependencies by running ```pip install -r requirements.txt```
* Run the project with ```python run.py```
* Test the project with ```python -m unittest```