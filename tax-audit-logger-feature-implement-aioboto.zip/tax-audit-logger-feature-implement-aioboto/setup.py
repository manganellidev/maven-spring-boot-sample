from setuptools import setup, find_packages


def get_version():
    with open('version.txt') as ver_file:
        version_str = ver_file.readline().rstrip()
    return version_str


def get_requirements():
    with open('requirements.txt') as f:
        requirements = f.read().splitlines()
    return requirements


setup(
    name='tax_audit_logger',  # Required
    version=get_version(),  # Required
    description='SAP Tax Service - Audit Logger',  # Required
    author='Globalization Services - CIS',
    author_email="DL_011000358700000071022012E@global.corp.sap",
    packages=find_packages(exclude=['tests']),  # Required
    install_requires=get_requirements(),
    test_requires=['mock', 'nose'],
    zip_safe=False,
    entry_points={"distutils.commands":
                      ["whitesource_update = plugin.WssPythonPlugin:SetupToolsCommand"]}
)
