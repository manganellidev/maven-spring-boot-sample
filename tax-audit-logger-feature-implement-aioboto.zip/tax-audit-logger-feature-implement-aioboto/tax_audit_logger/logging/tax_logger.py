import logging
from uuid import uuid4

from sap import cf_logging


class TaxLogger(object):

    def __init__(self, default_level=logging.INFO):
        self.logger = logging.getLogger("cli.logger")
        self.logger.setLevel(default_level)

    def info(self, message, correlation_id=None, new_correlation=False):
        self._do_log(self.logger.info, message, correlation_id, new_correlation)

    def warn(self, message, correlation_id=None, new_correlation=False):
        self._do_log(self.logger.warning, message, correlation_id, new_correlation)

    def error(self, message, correlation_id=None, new_correlation=False):
        self._do_log(self.logger.error, message, correlation_id, new_correlation)

    def _do_log(self, log_function, message, correlation_id=None, new_correlation=False):
        if new_correlation and not correlation_id:
            self._set_correlation_id(self._generate_correlation_id())
        elif correlation_id:
            self._set_correlation_id(correlation_id)
        log_function(message)
        self._clear_correlation_id()

    def _clear_correlation_id(self):
        self._set_correlation_id('')

    def _set_correlation_id(self, correlation_id):
        cf_logging.FRAMEWORK.context.set_correlation_id(correlation_id)

    def _generate_correlation_id(self):
        return str(uuid4())
