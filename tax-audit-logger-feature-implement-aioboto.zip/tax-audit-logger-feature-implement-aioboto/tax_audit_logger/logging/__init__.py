from sap import cf_logging


cf_logging.init()
