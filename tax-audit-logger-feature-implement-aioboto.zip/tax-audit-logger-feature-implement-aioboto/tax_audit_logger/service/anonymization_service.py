from tax_audit_logger.service.anonymization_parameters import IS_NATURAL_PERSON, DATA_MASK

fields_to_anonymize = ['address', 'zipCode', 'number']


def should_be_anonymized(audit_document):
    try:
        for party in audit_document.quote_request.get('parties', []):
            if party.get(IS_NATURAL_PERSON, False) is True:
                return True
        return False
    except Exception:
        return False


def anonymize_fields(obj, has_natural_person_on_parent=False):
    for key in obj.keys():
        if type(obj[key]) is list:
            if IS_NATURAL_PERSON in obj.keys() and obj[IS_NATURAL_PERSON] is True:
                for item in obj[key]:
                    anonymize_fields(item, True)
            else:
                for item in obj[key]:
                    anonymize_fields(item, False)

        if key in fields_to_anonymize and (
                has_natural_person_on_parent or (IS_NATURAL_PERSON in obj.keys() and obj[IS_NATURAL_PERSON] is True)):
            obj[key] = DATA_MASK
