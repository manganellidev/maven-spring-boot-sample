from tax_audit_logger.service.anonymization_parameters import IS_NATURAL_PERSON, DATA_MASK

positive_anonymization_values = ['Y', 'y']


def should_be_anonymized(audit_document):
    try:
        for party in audit_document.quote_request.get('Party', []):
            for tax_registration in party.get('taxRegistration', []):
                if tax_registration.get('taxNumberTypeCode') == IS_NATURAL_PERSON:
                    if tax_registration.get('taxNumber') in positive_anonymization_values:
                        return True
        return False
    except Exception:
        return False


def anonymize_fields(quote_request):
    _anonymize_locations(quote_request)
    _anonymize_parties(quote_request)


def _anonymize_locations(quote_request):
    parties_with_natural_person = _get_parties_with_natural_person(quote_request)
    [_anonymize_location(location) for location in quote_request.get('Locations', [])
     if location['type'] in parties_with_natural_person]


def _get_parties_with_natural_person(quote_request):
    parties = quote_request.get('Party', [])
    parties_with_natural_person = [party['role'] for party in parties for tax_registration in
                                   party.get('taxRegistration', [])
                                   if tax_registration.get('taxNumberTypeCode') == IS_NATURAL_PERSON and
                                   tax_registration.get('taxNumber') in positive_anonymization_values and
                                   'role' in party]
    return parties_with_natural_person


def _anonymize_location(location):
    address_fields = ['zipCode', 'addressLine1', 'addressLine2', 'addressLine3']
    for field in address_fields:
        if field in location:
            location[field] = DATA_MASK


def _anonymize_parties(quote_request):
    [_anonymize_party(party) for party in quote_request.get("Party", []) for tax_registration in
     party.get('taxRegistration', [])
     if tax_registration.get('taxNumberTypeCode') == IS_NATURAL_PERSON and
     tax_registration.get('taxNumber') in positive_anonymization_values]


def _anonymize_party(party):
    for tax_registration in party.get('taxRegistration', []):
        if tax_registration.get('taxNumberTypeCode') != IS_NATURAL_PERSON:
            if 'taxNumber' in tax_registration:
                tax_registration['taxNumber'] = DATA_MASK
