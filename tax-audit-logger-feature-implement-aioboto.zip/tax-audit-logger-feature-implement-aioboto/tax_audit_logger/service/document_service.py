import json
import dataclasses

from tax_audit_logger.persistence.audit_document import AuditDocument


def get_document_properties(audit_document: AuditDocument):
    document = dataclasses.asdict(audit_document)

    document_properties = {}
    document_properties['name'] = _generate_document_name(document)
    document_properties['content'] = _parse_to_file_object(document)
    return document_properties


def get_document_properties_with_personal_data(audit_document: AuditDocument):
    document = dataclasses.asdict(audit_document)

    document_properties = {}
    document_properties['name'] = _generate_document_name_with_personal_data(document)
    document_properties['content'] = _parse_to_file_object(document)
    return document_properties


def _generate_document_name(document):
    return f"{document['tenant_id']}/{document['creation']}_{document['correlation_id']}"


def _generate_document_name_with_personal_data(document):
    return f"{document['tenant_id']}/!dpp/{document['creation']}_{document['correlation_id']}"


def _parse_to_file_object(document):
    return json.dumps(document).encode('utf-8')
