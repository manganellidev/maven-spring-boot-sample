DATA_MASK = "********"
IS_NATURAL_PERSON = 'isNaturalPerson'
