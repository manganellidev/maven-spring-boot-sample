import uuid
from tax_audit_logger.logging.tax_logger import TaxLogger


def validate_message(properties, body):
    _validate_message_headers(properties)
    _validate_message_payload(body)


def _validate_message_headers(properties):
    if properties.headers.get('X-CorrelationID'):
        properties.headers['X-CorrelationID'] = properties.headers['X-CorrelationID'].decode('utf-8')
    else:
        correlation_id = _generate_unique_id()
        properties.headers['X-CorrelationID'] = correlation_id
        TaxLogger().warn(f'The "X-correlationID" header was not informed in the message. '
                         f'Correlation ID {correlation_id} was created for your transaction.')


def _validate_message_payload(body):
    error_message = 'The "{}" field must be filled in to save the audit log document.'
    quote_request = body.get('quoteRequest')
    quote_response = body.get('quoteResponse')
    quote_trace = body.get('quoteTrace')
    tenant_id = body.get('tenantId')

    contract_errors = []

    if quote_request is None:
        contract_errors.append({'error': error_message.format("quoteRequest")})

    if quote_response is None:
        contract_errors.append(
            {'error': error_message.format("quoteResponse")})

    if quote_trace is None:
        contract_errors.append({'error': error_message.format("quoteTrace")})

    if tenant_id is None:
        contract_errors.append({'error': error_message.format("tenantId")})

    if len(contract_errors) > 0:
        raise ValueError(contract_errors)


def _generate_unique_id():
    return str(uuid.uuid4())
