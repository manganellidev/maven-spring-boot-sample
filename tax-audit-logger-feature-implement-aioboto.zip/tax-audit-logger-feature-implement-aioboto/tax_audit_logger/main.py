from time import sleep
from tax_audit_logger.communication.setup import create_channel, configure_queue, start_consuming_queue
from tax_audit_logger.environment.cloud_foundry import CloudFoundryEnvironment
from tax_audit_logger.logging.tax_logger import TaxLogger


async def main(loop):
    try:
        channel = await create_channel(CloudFoundryEnvironment().get_rabbitmq_uri(), loop)
        queue = await configure_queue(channel)
        await start_consuming_queue(queue)
    except Exception as ex:
        TaxLogger().error("A runtime error has occurred: " + str(ex))
        TaxLogger().info("Waiting 60 seconds to restart main routine again...")
        await _restart_after_cool_down(60)


async def _restart_after_cool_down(cooling_time):
    sleep(cooling_time)
    await main()
