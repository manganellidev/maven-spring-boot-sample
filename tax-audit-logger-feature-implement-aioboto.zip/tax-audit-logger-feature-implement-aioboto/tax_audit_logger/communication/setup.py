import aio_pika
import json
from tax_audit_logger.communication.parameters import QUEUE, EXCHANGE
from tax_audit_logger.communication.worker import create_audit_document
from tax_audit_logger.logging.tax_logger import TaxLogger


async def create_channel(uri, loop):
    connection = await aio_pika.connect_robust(uri, loop=loop)
    return await connection.channel()


async def configure_queue(channel):
    queue = await channel.declare_queue(name=QUEUE, durable=True, auto_delete=False)
    await channel.set_qos(prefetch_count=100)
    await channel.declare_exchange(name=EXCHANGE, durable=True, type=aio_pika.ExchangeType.FANOUT)
    await queue.bind(exchange=EXCHANGE)
    return queue


async def start_consuming_queue(queue):
    await queue.consume(_process_message_callback)


async def _process_message_callback(message):
    try:
        async with message.process():
            await create_audit_document(message.properties, json.loads(message.body))
    except Exception as ex:
        TaxLogger().error('An error has occurred when saving log with correlation ID {}. '
                        'Error was: {}'.format(message.properties.headers.get('X-CorrelationID', '-'),
                                                str(ex)))
