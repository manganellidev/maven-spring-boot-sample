import uuid
from datetime import datetime
from tax_audit_logger.service import anonymization_service, anonymization_v0_service, validation_service, \
    document_service
from tax_audit_logger.environment.cloud_foundry import CloudFoundryEnvironment
from tax_audit_logger.logging.tax_logger import TaxLogger
from tax_audit_logger.persistence.audit_document import AuditDocument
from tax_audit_logger.persistence import store


async def create_audit_document(properties, body):
    validation_service.validate_message(properties, body)
    audit_document = _convert_message_to_audit_document(properties, body)

    if _is_v0(properties):
        await _handle_document_creation(audit_document, anonymization_v0_service)
    else:
        await _handle_document_creation(audit_document, anonymization_service)


def _convert_message_to_audit_document(properties, body):
    return AuditDocument(
        _id=_generate_unique_id(),
        tenant_id=body['tenantId'],
        correlation_id=properties.headers['X-CorrelationID'],
        creation=str(datetime.utcnow().isoformat()),
        quote_request=body['quoteRequest'],
        quote_response=body['quoteResponse'],
        quote_trace=body['quoteTrace']
    )


def _generate_unique_id():
    return str(uuid.uuid4())


def _is_v0(properties):
    not_found = -1
    audit_document_id = properties.headers.get('__TypeId__', b'').decode('utf-8')
    return False if audit_document_id.find('v0') == not_found else True


async def _handle_document_creation(audit_document, anonymization_service):
    if anonymization_service.should_be_anonymized(audit_document):
        await _handle_document_creation_with_anonymization(
            audit_document, anonymization_service)
    else:
        await _handle_regular_document_creation(audit_document)


async def _handle_document_creation_with_anonymization(audit_document, anonymization_service):
    document_properties = document_service.get_document_properties_with_personal_data(
        audit_document)
    await _save_audit_document(document_properties)

    anonymization_service.anonymize_fields(audit_document.quote_request)
    await _handle_regular_document_creation(audit_document)


async def _handle_regular_document_creation(audit_document):
    document_properties = document_service.get_document_properties(
        audit_document)
    await _save_audit_document(document_properties)


async def _save_audit_document(document_properties):
    credentials = CloudFoundryEnvironment().get_object_store_credentials()
    await store.put_object(document_properties, credentials)
    TaxLogger().info(f'Audit Document created: {document_properties["name"]}')
