EXCHANGE = 'txs.audit-logger'
QUEUE = 'txs.audit-logger.audit-document-quote'
