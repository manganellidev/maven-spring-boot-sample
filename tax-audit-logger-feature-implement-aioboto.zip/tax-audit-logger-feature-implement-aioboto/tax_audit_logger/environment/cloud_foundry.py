from cfenv import AppEnv


class CloudFoundryEnvironment(object):

    def __init__(self):
        self.app_env = AppEnv()

    def get_object_store_credentials(self):
        try:
            return self._get_service('objectstore').credentials
        except Exception:
            return self._get_service('user-provided').credentials

    def get_rabbitmq_uri(self):
        return self._get_service('rabbitmq').credentials['uri']

    def _get_service(self, service_label):
        service = self.app_env.get_service(label=service_label)
        return service
