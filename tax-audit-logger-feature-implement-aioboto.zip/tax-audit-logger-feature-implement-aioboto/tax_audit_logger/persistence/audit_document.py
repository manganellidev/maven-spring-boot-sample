from dataclasses import dataclass

@dataclass
class AuditDocument:
    _id: str
    tenant_id: str
    correlation_id: str
    creation: str
    quote_request: dict
    quote_response: dict
    quote_trace: dict
