import aioboto3


async def put_object(document_properties, credentials):
    async with aioboto3.client('s3',
                    aws_access_key_id=credentials['access_key_id'],
                    aws_secret_access_key=credentials['secret_access_key'],
                    region_name=credentials['region']) as client:
        await client.put_object(Bucket=credentials['bucket'],
                    Body=document_properties['content'],
                    Key=document_properties['name'])
